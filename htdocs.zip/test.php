<?php
  echo "helloda";
  echo "<br>";
  /*
  주석
  */
  // 주석
  $num1=33;
  $num2=33.3;
  $num3="kiminkyu";
  echo "\$num1=$num1<br>";
  echo "\$num2=$num2<br>";
  echo "\$num3=$num3<br>";
  echo "세과목의 평균을 구합니다<br>";
  echo "=======================<br>";
  $math=100;
  $english=45;
  $korean=37;
  echo "math point:$math<br>";
  echo "english point:$english<br>";
  echo "korean poin:$korean<br>";
  echo "=======================<br>";
  echo "total:$math+$english+$korean<br>";
  echo "average:($math+$english+$korean)/3<br>"
  echo "=======================<br>";
  echo "What is the type of \$math?";
  echo gettype($math);
?>
