<?php
/*
  echo "알파벳 대문자 싹 다 출력 <br>";
  for($a=65;$a<=90;$a++){
    echo chr($a);
    echo " ";
  }
  echo "<br>";
  echo "알파벳 소문자 싹다 출력<br>";
  for($b=97;$b<=122;$b++){
    echo chr($b);
    echo " ";
  }
  echo "<br>";
  echo "ord()를 이용하여 숫자출력<br>";
  $c='A';
  echo ord($c);
  echo " ";
  echo "<br>";
  echo "php배열에 알파벳 소문자 저장후 다시 바꿔서 출력<br>";
  $array123 = array(1,2,3,4,5);
  echo "<br>";
  echo $array123[0];
  echo $array123[1];
  echo $array123[2];
  echo $array123[3];
  echo $array123[4];
  print "<br>";
  $f=334;
  $array123[0]=$f;
  echo $array123[0];

  for($e=0;$e<=4;$e++){
    for($d=97;$d<102;$d++){
      $array123[$e]=$d;
    }
  }
  foreach($array123 as $dd){
    echo $dd.' ';
  }
  */
  $a = "hello world";
  $str = substr($a,2);
  echo "$str";
  $str = strchr($a,"o");
  echo "$str";
?>
