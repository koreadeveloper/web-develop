const kiminkyu = {
  name:"kiminkyu",
  age:17,
  gender:"Male",
  isHandsome:true,
  weight:60.0,
  favoriteFood: ["kimchi","blgogi","pizza","chicken"],
  favoriteMovie: [
    {name:"marvel",money:high},
    {name:"DC",money:low}
  ]
}

console.log(kiminkyu.name);
console.log(kiminkyu.age);
console.log(kiminkyu.gender);
console.log(kiminkyu.isHandsome);
console.log(kiminkyu.weight);
kiminkyu.weight = 60.1;
console.log(kiminkyu.weight);
