<?php
/*
  $userAdd = array("a","b","c","d");
  foreach ($userAdd as $key) {
    echo "$key<br>";// code...
  }
  echo "$key<br>";
  $userArr = array('a'=>'b','b'=>'c','c'=>'a');
  foreach($userArr as  $wqeweq){
    echo "$wqeweq<br>";
  }
  echo $userArr['a'];
*/
function helloworld(){
  echo "Helloworld<br>";
}
helloworld();
function otput($qaz='User'){
  echo $qaz.' 님안녕하세요';
}
$qpo="kiminho";
otput($qpo);
otput();
echo "<br>";
function numlist($aa,$bb){
  if($aa<=$bb){
    for(;$aa<=$bb;$aa++){
      echo "$aa<br>";
    }
  }
  else if($aa>=$bb){
    for(;$bb<=$aa;$bb++){
      echo "$bb<br>";
    }
  }
}
numlist(3,10);
numlist(10,3);

/*
echo "단방향 암호화 crypt() 함수 <br />";
$char = "arigatou";
echo  "현재 암호화가 되어있지 않은 상태의 비밀번호 : {$char} <br /> ";
$passwd = crypt($char); // 변수 선언후 $char을 암호화 처리
echo  "암호화 처리된 비밀번호 {$passwd} <br />";
*/
/*
$passwd = "abc123";
$char = "as";
echo "암호로 지정한 문자열 : abc123<br>";
echo "암호화 : ";
echo  crypt($a, $b);
*/
/*
$testSen = "kiminkyu";
$password = crypt($testSen); //단방향 암호화
echo "$password";
strtoupper($testSen) //문자열의 알파벳을 모두 대문자로 변환
echo "$testSen";
strtolower($testSen) //문자열의 알파벳을 모두 소문자로 변환
echo "$testSen";
strlen($testSen) //문자열의 길이 반환
echo "$testSen";
ord($testSen) //문자에 해당하는 아스키 코드값을 반환
echo "$testSen";
chr() //아스키 코드값에 해당하는 문자를 반환
echo "$testSen";
nl2br($testSen) //"New Line To HTML. <br />" 태그로 엔터를 입력한 부분의 줄 바꿈
echo "$testSen";
echo($testSen)
echo "$testSen";
print($testSen) //문자열 출력
echo "$testSen";
printf($testSen)
echo "$testSen";
sprintf($testSen) //형식이 있는 문자열 출력
echo "$testSen";
substr($testSen) //문자열에서 자르기를 시작할 위치를 왼쪽에서부터 배열 수로 설정
echo "$testSen";
strchr($testSen) //문자열을 자르기 시작할 문자열의 문자로 위치를 표시
echo "$testSen";
chop($testSen) //문자열의 뒷부분에 있는 공백을 제거
echo "$testSen";
trim($testSen) //문자열의 앞과 뒤에 있는 공백을 제거 (앞 ltrim(), 뒤 rtrim() 로 제거)
echo "$testSen";
explode($testSen) //문자열을 배열로 반환
echo "$testSen";
str_replace($testSen) //임의의 문자열에서 특정 문자를 다른 문자로 변경
echo "$testSen";
preg_match($testSen) //임의의 문자열에서 찾을 문자열이 존재한다면 1, 아니면 0을 반환
echo "$testSen";
ereg($testSen) //문자열 검색에서 알파벳 대/소문자를 정확히 구별하여 검색
echo "$testSen";
eregi($testSen) //문자열 검색에서 알파벳 대/소문자의 구분 없이 검색
echo "$testSen";
strcmp($testSen) //두 개의 문자열에서 첫 글자의 아스키 코드값에 따라 1, 0, 01을 반환
echo "$testSen";
addslashes($testSen) //역슬래시 삽입
echo "$testSen";
strslashes($testSen) //역슬래시 제거
echo "$testSen";
*/
echo "hu";
print "hu";
echo "<br>";

$floata = 123.123;
$floatb = 43.12;

echo "\$floata = $floata<br>";
echo "\$floatb = $floatb<br>";
$form1 = sprintf("\ %0.2f",$floata*$floatb);
$form2 = sprintf("\ %0.2f",$floata/$floatb);

echo "변수가 a=$floata,b=$floatb 일떄 <br>";
printf("1. %0.3f 와 %0.3f의 덧셈.. %0.2f",$floata,$floatb,$floata+$floatb);
echo "<br>";
echo "곱셈 : {$form1}<br>";
echo "나눗셈 : $form2 <br>";
?>
