<?php
/*
  echo " 3과목의 평균을 구해보아요 ";
  echo "---------------------------- <br />";
 
  $math = 100;
  $english = 95;
  $science = 85;
 
  $sum = $math + $english + $science;       // < ===== $sum이라는 변수를 만들고 값은 3과목의 합이다.
  $avg = $sum/3;                                           //     3으로나눠서 평균값이 $avg의 값이 된다.
 
  echo " math point : $math <br /> english point : $english <br /> science point : $science <br />";
  echo "======================== <br />"; 
  echo " total : $sum <br />";
  echo " average : $avg <br />"; 
  echo "======================== <br />";
  echo " what is the type of \$avg?  <br />";
  echo gettype($avg);
  $num_test = 2147483647;
  $num_te = 2147483648;
  echo "$num_test<br>";
  var_dump($num_test);
  var_dump($num_te);
  $qwe="korea";
  $rty="developer";
  $qwe.=$rty;
  echo "$qwe";
  */
  $a=50;
  $b=60;
  if($a==50){
    echo "$a<br>";
  }
  if($a>=50&&$b>=50){
    echo "$a & $b<br>";
  }
  $c=1;
  for($c=1;$c<=10;$c++){
    echo "$c<br>";
  }
  $d=1;
  $e=2;
  for($e=2;$e<=9;$e++){
    $result=$d*$e;
    for($d=1;$d<=9;$d++){
      if($e==3){
        continue;
        // 3단 출력안함
      }
      echo "$e X $d = $d*$e<br>";
    }
  }
?>
